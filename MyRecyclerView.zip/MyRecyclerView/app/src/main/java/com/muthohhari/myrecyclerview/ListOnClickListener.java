package com.muthohhari.myrecyclerview;

import android.view.View;

public interface ListOnClickListener {
    void onClick(View view,int position);
}
